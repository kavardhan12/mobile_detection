# mobile_talk_detection > 2024-06-12 2:43pm
https://universe.roboflow.com/ananda-vardhan-fpy6p/mobile_talk_detection

Provided by a Roboflow user
License: CC BY 4.0

