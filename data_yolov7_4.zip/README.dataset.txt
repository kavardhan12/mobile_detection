# mobile_invisible_zone > 2024-06-14 6:37am
https://universe.roboflow.com/ananda-vardhan-fpy6p/mobile_invisible_zone

Provided by a Roboflow user
License: CC BY 4.0

